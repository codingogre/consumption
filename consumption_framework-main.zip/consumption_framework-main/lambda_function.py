import json
import logging
import os
import sys
from datetime import datetime, timedelta
import boto3
from botocore.exceptions import ClientError

import pytz
import requests

from consumption import Consumption

logger = logging.getLogger(__name__)


def _unpack_flat_dict(d):
    """
    Transforms a flat dictionary into a nested dictionary.
    {
        "a.b": 1,
        "a.c": 2,
        "a.d.foo": 3
    }

    into

    {
        "a": {
            "b": 1,
            "c": 2,
            "d": {
                "foo": 3
            }
        }
    }
    """

    result = {}
    for key, value in d.items():
        keys = key.split(".")
        current = result
        for k in keys[:-1]:
            current = current.setdefault(k, {})
        current[keys[-1]] = value
    return result


def handler(event, context):
    env = os.environ

    logging.basicConfig(
        stream=sys.stdout,
        format="%(asctime)s [%(threadName)s] - %(levelname)s (%(name)s): %(message)s",
        level=logging.DEBUG if "debug" in env else logging.INFO,
    )

    if "config_arn" not in env:
        logger.error("config_arn is required in environment variables")
        sys.exit(1)

    if "command" not in env:
        logger.error("command is required in environment variables")
        sys.exit(1)

    if "region" not in env:
        logger.error("command is required in environment variables")
        sys.exit(1)

    secret_value = get_secret(env["config_arn"], env["region"])
    config = _unpack_flat_dict(secret_value)

    # Convert the string values to the correct types
    if config.get('monitoring_source') and config['monitoring_source'].get('retry_on_timeout'):
      config['monitoring_source']['retry_on_timeout'] = config['monitoring_source']['retry_on_timeout'].lower() == 'true'

    if config.get('monitoring_source') and config['monitoring_source'].get('request_timeout'):
      config['monitoring_source']['request_timeout'] = int(config['monitoring_source']['request_timeout'])

    command = env["command"]
    threads = int(env.get("threads", 5))
    lookbehind = int(env.get("lookbehind", 24))
    force = bool(env.get("force", False))
    compute_usages = bool(env.get("compute_usages", False))

    to_ts = datetime.now(tz=pytz.UTC)
    from_ts = to_ts - timedelta(hours=lookbehind)
    
    Consumption(
        organization_id=None,
        organization_name=None,
        billing_api_key=None,
        destination_config=config["consumption_destination"],
        api_host="api.elastic-cloud.com",
        monitoring_index_pattern=config.get(
                "monitoring_index_pattern", ".monitoring-es-8-*"
        ),
    ).init()

    if command == "consume-monitoring":
        Consumption(
            organization_id=config.get("organization_id"),
            organization_name=config["organization_name"],
            billing_api_key=config.get("billing_api_key"),
            on_prem_costs_dict=config.get("on_prem_costs"),
            destination_config=config["consumption_destination"],
            source_config=config["monitoring_source"],
            threads=threads,
            force=force,
            compute_usages=compute_usages,
            api_host="api.elastic-cloud.com",
            monitoring_index_pattern=config.get(
                "monitoring_index_pattern", ".monitoring-es-8-*"
            ),
        ).consume_monitoring(from_ts, to_ts)
    elif command == "get-billing-data":
        Consumption(
            organization_id=config["organization_id"],
            organization_name=config["organization_name"],
            billing_api_key=config["billing_api_key"],
            destination_config=config["consumption_destination"],
            threads=threads,
            force=force,
            api_host="api.elastic-cloud.com",
            monitoring_index_pattern=config.get(
                "monitoring_index_pattern", ".monitoring-es-8-*"
            ),
        ).get_billing_data(from_ts, to_ts)
    elif command == "both":
        Consumption(
            organization_id=config.get("organization_id"),
            organization_name=config["organization_name"],
            billing_api_key=config.get("billing_api_key"),
            on_prem_costs_dict=config.get("on_prem_costs"),
            destination_config=config["consumption_destination"],
            source_config=config["monitoring_source"],
            threads=threads,
            force=force,
            compute_usages=compute_usages,
            api_host="api.elastic-cloud.com",
            monitoring_index_pattern=config.get(
                "monitoring_index_pattern", ".monitoring-es-8-*"
            ),
        ).consume_monitoring(from_ts, to_ts)

        Consumption(
            organization_id=config["organization_id"],
            organization_name=config["organization_name"],
            billing_api_key=config["billing_api_key"],
            destination_config=config["consumption_destination"],
            threads=threads,
            force=force,
            api_host="api.elastic-cloud.com",
            monitoring_index_pattern=config.get(
                "monitoring_index_pattern", ".monitoring-es-8-*"
            ),
        ).get_billing_data(from_ts, to_ts)
    else:
        logger.error(f"Unknown command: {command}")
        sys.exit(1)

    return 'Hello from AWS Lambda using Python'

def get_secret(secret_name, region_name):
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        # Get the secret value
        get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    except ClientError as e:
        # Handle exceptions (e.g., secret not found, insufficient permissions)
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the secret using the provided KMS key
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # The requested secret does not exist
            raise e
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            secret = get_secret_value_response['SecretBinary']

        # If the secret is a JSON string, you can load it as a dictionary
        try:
            secret = json.loads(secret)
        except json.JSONDecodeError:
            # If the secret is not JSON formatted, return it as a string
            pass

        return secret