import logging
from dataclasses import asdict, dataclass
from datetime import datetime
from hashlib import sha1
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass(kw_only=True)
class SolutionCost:
    """
    Dataclass to represent an ESS cost.
    """

    time: datetime  # Costs are computed hourly, this should correspond to the end of the hour for which the cost is computed.
    category: str  # DTS vs resource cost
    type: str  # Sub-category, this can be something like elasticsearch, kibana, S3 storage, etc...
    name: str  # Human readable name for the cost
    sku: str  # SKU of the cost, internal Elastic identifier
    quantity: float  # Quantity of the resource used
    rate: float  # Hourly rate in USD
    cost: float  # Hourly cost in USD, cost = quantity * rate

    # Meta fields
    organization_id: str = ""
    organization_name: Optional[str] = None
    deployment_id: str = ""
    deployment_name: str = ""

    def as_elasticsearch_doc(self):
        """
        Returns the cost as a dictionary to be stored in Elasticsearch.
        This adds the necessary metadata fields for direct indexing.
        """
        res = asdict(self)

        # Need microsecond precision for @timestamp
        res["@timestamp"] = self.time.isoformat(timespec="milliseconds")
        res["_op_type"] = "index"
        res["_index"] = "consumption"
        res["_id"] = sha1(
            (
                self.organization_id
                + self.deployment_id
                + self.sku
                + self.time.isoformat()
            ).encode("utf-8")
        ).hexdigest()

        res["dataset"] = "deployment"

        # Remove the time, as we'll use @timestamp instead
        del res["time"]

        return res


@dataclass
class ResourceCost(SolutionCost):
    """
    Represents a resource cost (e.g. compute instance)
    """

    category: str = "resource"

    @classmethod
    def from_api_response(cls, d: dict, **kwargs):
        """
        Create a ResourceCost from the ESS API response
        """
        # kwargs will need to declare the necessary attributes
        return cls(
            type=d["kind"],
            name=d["name"],
            sku=d["sku"],
            quantity=d["hours"],
            rate=d["price_per_hour"],
            cost=d["price"],
            **kwargs,
        )


@dataclass
class DTSCost(SolutionCost):
    """
    Represents a DTS cost (e.g. S3 transfer, S3 storage, etc...)
    """

    category: str = "dts"

    @classmethod
    def from_api_response(cls, d: dict, **kwargs):
        """
        Create a DTSCost from the ESS API response
        """
        # kwargs will need to declare the necessary attributes
        return cls(
            type=d["type"],
            name=d["name"],
            sku=d["sku"],
            quantity=d["quantity"]["value"],
            rate=d["rate"]["value"],
            cost=d["cost"],
            **kwargs,
        )
