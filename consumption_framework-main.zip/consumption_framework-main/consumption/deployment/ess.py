import logging
import re
from datetime import datetime

import pandas as pd
import requests

from ..utils import ESSURLs

logger = logging.getLogger(__name__)


class DeploymentFinder:
    def __init__(self, ess_api_key: str, organization_id: str, api_host: str):
        es_filters = [
            {
                "nested": {
                    "path": "resources.elasticsearch",
                    "query": {"exists": {"field": "resources.elasticsearch.id"}},
                }
            },
            {
                "nested": {
                    "path": "resources.elasticsearch",
                    "query": {
                        "match": {
                            "resources.elasticsearch.info.settings.metadata.organization_id": {
                                "query": organization_id
                            }
                        }
                    },
                }
            },
        ]

        res = requests.post(
            url=ESSURLs(api_host).ESS_SEARCH_DEPLOYMENTS_URL,
            headers={"Authorization": "ApiKey " + ess_api_key},
            json={
                "size": 1500,
                "query": {"bool": {"filter": es_filters}},
            },
        )
        res.raise_for_status()

        deployments = res.json()["deployments"]

        logger.debug(
            f"Found {len(deployments)} deployments for organization {organization_id}"
        )

        self.deployments = deployments
        self.elasticsearch_id_cache = {}
        self.deployment_id_cache = {}

    def get_deployment_id(self, elasticsearch_id: str) -> str:
        """
        Get the deployment id for the given elasticsearch_id.
        """
        if elasticsearch_id not in self.elasticsearch_id_cache:
            for deployment in self.deployments:
                for es in deployment["resources"]["elasticsearch"]:
                    if es["info"]["cluster_id"] == elasticsearch_id:
                        logger.debug(
                            f"Found deployment ID {deployment['id']} "
                            f"for elasticsearch_id {elasticsearch_id}"
                        )

                        # Populate both caches
                        self.elasticsearch_id_cache[elasticsearch_id] = deployment["id"]
                        self.deployment_id_cache[deployment["id"]] = elasticsearch_id

        return self.elasticsearch_id_cache.get(elasticsearch_id)


def get_elasticsearch_costs(
    organization_id: str,
    deployment_id: str,
    ess_api_key: str,
    from_ts: datetime,
    to_ts: datetime,
    api_host: str,
) -> pd.DataFrame:
    """
    Get cost of individual ES instances for a given deployment.
    Returns a dict of {instance_configuration: price}
    Since this can vary over time, we use the given time to fetch the costs.
    """
    logger.debug(
        f"Fetching costs for deployment {deployment_id} between {from_ts.isoformat()} and {to_ts.isoformat()}"
    )

    res = requests.get(
        url=ESSURLs(api_host).ESS_BILLING_URL % (organization_id, deployment_id),
        headers={"Authorization": "ApiKey " + ess_api_key},
        params={
            "from": from_ts.isoformat(timespec="microseconds"),
            "to": to_ts.isoformat(timespec="microseconds"),
        },
    )
    res.raise_for_status()

    resources = res.json().get("resources", [])

    prices = []
    for resource in resources:
        if resource.get("kind") == "elasticsearch":
            instance_price_per_hour = float(resource["price_per_hour"])
            instance_az_count = None
            instance_ram_per_az = None
            tier = "unknown"
            name_lower = resource["name"].lower()

            if "hot" in name_lower:
                tier = "hot"
            elif "high i/o" in name_lower:
                tier = "hot"
            elif "warm" in name_lower:
                tier = "warm"
            elif "cold" in name_lower:
                tier = "cold"
            elif "frozen" in name_lower:
                tier = "frozen"
            else:
                # Probably some ml / master nodes
                continue

            pattern = r", (\d+)GB, (\d+)AZ"
            matches = re.search(pattern, resource["name"])

            if matches:
                instance_ram_per_az = int(matches.group(1))
                instance_az_count = int(matches.group(2))
            else:
                # Fallback to the sku if we can't parse the name
                # Cloud Enterprise Data High I/O l32sv2 Azure EU North (Ireland) 406 GB HA (2 Zones) SSD
                # Cloud-Enterprise_azure.data.highio.l32sv2_azure-northeurope_415744_2

                logger.warning(
                    f"Could not parse \"{resource['name']}\" to get RAM per zone and AZ count, reverting to sku"
                )
                pattern = r"_(\d+)_(\d+)$"
                matches = re.search(pattern, resource["sku"])
                if matches:
                    instance_ram_per_az = int(matches.group(1)) / 1024
                    instance_az_count = int(matches.group(2))
                else:
                    raise Exception(
                        f"Could not parse \"{resource['sku']}\" to get RAM per zone and AZ count, aborting"
                    )

            # If we already have a price for this tier, log it
            if tier in [price["tier"] for price in prices]:
                logger.warning(
                    f"Found multiple prices for tier {tier} for deployment {deployment_id} between {from_ts.isoformat()} and {to_ts.isoformat()}"
                )
                logger.warning(f"Full resources: {resources}")

            # Compute the price per hour per GB RAM for this tier
            price_per_hour_per_gb = instance_price_per_hour / (
                instance_ram_per_az * instance_az_count
            )

            prices.append(
                {
                    "tier": tier,
                    "price_per_hour_per_gb": price_per_hour_per_gb,
                }
            )

    return pd.DataFrame(prices).set_index("tier") if prices else pd.DataFrame()
