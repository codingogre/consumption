import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from elasticsearch import Elasticsearch

from .deployment import monitoring_analyzer
from .organization import organization_billing

logger = logging.getLogger(__name__)


# TODO: we'll probably want to clean this up, as calls are separate from one another
class Consumption:
    def __init__(
        self,
        organization_id: str,
        organization_name: str,
        billing_api_key: str,
        destination_es: Elasticsearch,
        monitoring_index_pattern: str,
        api_host: str,
        threads: int = 5,
        on_prem_costs_dict: Optional[Dict[str, float]] = None,
        force: bool = False,
    ):
        self.organization_id = organization_id
        self.organization_name = organization_name
        self.billing_api_key = billing_api_key
        self.on_prem_costs_dict = on_prem_costs_dict
        self.destination_es = destination_es
        self.threads = threads
        self.force = force
        self.api_host = api_host
        self.monitoring_index_pattern = monitoring_index_pattern

        logger.info(f"Created consumption object for {self.organization_name}")

    def init(self):
        """
        Uploads all assets (index templates, ILM policies, ingest pipelines...)
        Necessary to the consumption package.
        """

        logger.info("Initializing consumption package Elasticsearch assets")

        # Read local meta files,
        # and create the corresponding assets on the cluster
        base_path = Path(__file__).parent

        # Load the ingest pipeline
        logger.debug("Pushing ingest pipeline")
        with open(
            base_path / "_meta" / "ingest_pipeline.json", "r"
        ) as ingest_pipeline_file:
            self.destination_es.ingest.put_pipeline(**json.load(ingest_pipeline_file))

        # ILM policy
        logger.debug("Pushing ILM policy")
        with open(base_path / "_meta" / "ilm_policy.json", "r") as ilm_policy_file:
            self.destination_es.ilm.put_lifecycle(**json.load(ilm_policy_file))

        # Index template
        logger.debug("Pushing solution index template")
        with open(
            base_path / "_meta" / "index_template.json", "r"
        ) as index_template_file:
            self.destination_es.indices.put_index_template(
                **json.load(index_template_file)
            )

    def get_billing_data(
        self,
        from_ts: datetime,
        to_ts: datetime,
    ):
        organization_billing(
            destination_es=self.destination_es,
            organization_id=self.organization_id,
            organization_name=self.organization_name,
            billing_api_key=self.billing_api_key,
            from_ts=from_ts,
            to_ts=to_ts,
            threads=self.threads,
            force=self.force,
            api_host=self.api_host,
        )

    def consume_monitoring(
        self,
        source_es: Elasticsearch,
        from_ts: datetime,
        to_ts: datetime,
    ):
        monitoring_analyzer(
            source_es=source_es,
            destination_es=self.destination_es,
            organization_id=self.organization_id,
            organization_name=self.organization_name,
            billing_api_key=self.billing_api_key,
            from_ts=from_ts,
            to_ts=to_ts,
            threads=self.threads,
            force=self.force,
            api_host=self.api_host,
            monitoring_index_pattern=self.monitoring_index_pattern,
            on_prem_costs_dict=self.on_prem_costs_dict,
        )


__all__ = ["Consumption"]
