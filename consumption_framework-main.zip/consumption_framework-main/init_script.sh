#!/bin/bash
###took out init status, because it shouldn't cause an issue if it runs again. 

# Setup the cron job using the provided environment variable
# if [ ! -z "$CRON_SCHEDULE" ]; then
#     echo "Setting up cron job with schedule: $CRON_SCHEDULE"
#     echo "$CRON_SCHEDULE /cron_job.sh" | crontab -
# else
#     echo "No CRON_SCHEDULE environment variable set. Skipping cron setup."
# fi
# /usr/local/bin/python /main.py init

# # Start the cron daemon in the background
# cron -f &
# echo "Cron job setup completed."

# echo "Starting to tail /dev/null..."
# tail -f /dev/null



# Check if BILLING_API_KEY is defined and any of the on_prem_costs variables are defined
if [ ! -z "${BILLING_API_KEY}" ] && ( [ ! -z "${ON_PREM_COSTS_HOT}" ] || [ ! -z "${ON_PREM_COSTS_WARM}" ] || [ ! -z "${ON_PREM_COSTS_COLD}" ] || [ ! -z "${ON_PREM_COSTS_FROZEN}" ] ); then
    echo "Both BILLING_API_KEY and on_prem_costs are defined. Terminating the script."
    exit 1
fi

cat > config.yml <<EOL
organization_id: "${ORGANIZATION_ID}"
organization_name: "${ORGANIZATION_NAME}"
EOL

# Add billing_api_key if defined
if [ ! -z "${BILLING_API_KEY}" ]; then
    cat >> config.yml <<EOL
billing_api_key: "${BILLING_API_KEY}"
EOL
fi

# Include on_prem_costs if BILLING_API_KEY is not defined and on_prem_costs variables are defined
if [ -z "${BILLING_API_KEY}" ]; then
    cat >> config.yml <<EOL
on_prem_costs:
  hot: ${ON_PREM_COSTS_HOT:-1.0}
  warm: ${ON_PREM_COSTS_WARM:-0.5}
  cold: ${ON_PREM_COSTS_COLD:-0.25}
  frozen: ${ON_PREM_COSTS_FROZEN:-0.1}
EOL
fi

cat >> config.yml <<EOL
monitoring_source:
  hosts: "${MONITORING_HOSTS}"
  api_key: "${MONITORING_API_KEY}"
  max_retries: ${MONITORING_MAX_RETRIES:-5}
  retry_on_timeout: ${MONITORING_RETRY:-true}
  request_timeout: ${MONITORING_TIMEOUT:-60}
  verify_certs: ${MONITORING_VERIFY_CERTS:-true}
consumption_destination:
  hosts: "${CONSUMPTION_HOSTS}"
  api_key: "${CONSUMPTION_API_KEY}"
  max_retries: ${CONSUMPTION_MAX_RETRIES:-5}
  retry_on_timeout: ${CONSUMPTION_RETRY:-true}
  request_timeout: ${CONSUMPTION_TIMEOUT:-60}
  verify_certs: ${CONSUMPTION_VERIFY_CERTS:-true}
EOL

# Setup the cron job using the provided environment variable
if [ ! -z "$CRON_SCHEDULE" ]; then
    echo "Setting up cron job with schedule: $CRON_SCHEDULE"
    echo "$CRON_SCHEDULE /cron_job.sh" | crontab -
else
    echo "No CRON_SCHEDULE environment variable set. Skipping cron setup."
fi

/usr/local/bin/python /main.py init

# Start the cron daemon in the background
cron -f &
echo "Cron job setup completed."

echo "Starting to tail /dev/null..."
tail -f /dev/null
