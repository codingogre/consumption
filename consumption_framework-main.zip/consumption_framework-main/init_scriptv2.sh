#!/bin/bash
# Check if BILLING_API_KEY is defined and any of the on_prem_costs variables are defined
if [ ! -z "${BILLING_API_KEY}" ] && ([ ! -z "${ON_PREM_COSTS_HOT}" ] || [ ! -z "${ON_PREM_COSTS_WARM}" ] || [ ! -z "${ON_PREM_COSTS_COLD}" ] || [ ! -z "${ON_PREM_COSTS_FROZEN}" ]); then
    echo "Both BILLING_API_KEY and on_prem_costs are defined. Terminating the script."
    exit 1
fi
#tail -f /dev/null
# Construct the JSON configuration
CONFIG_JSON=$(cat <<EOF
{
  "organization_id": "${ORGANIZATION_ID}",
  "organization_name": "${ORGANIZATION_NAME}",
EOF
)

# Conditionally add billing_api_key to CONFIG_JSON if it's defined
if [ -n "${BILLING_API_KEY}" ]; then
    CONFIG_JSON="${CONFIG_JSON}
  \"billing_api_key\": \"${BILLING_API_KEY}\","
fi

# Continue adding the rest of the configuration
CONFIG_JSON="${CONFIG_JSON}
  \"consumption_destination\": {
    \"hosts\": \"${CONSUMPTION_HOSTS}\",
    \"api_key\": \"${CONSUMPTION_API_KEY}\",
    \"max_retries\": ${CONSUMPTION_MAX_RETRIES:-5},
    \"retry_on_timeout\": ${CONSUMPTION_RETRY:-true},
    \"request_timeout\": ${CONSUMPTION_TIMEOUT:-60},
    \"verify_certs\": ${CONSUMPTION_VERIFY_CERTS:-true}
  },
  \"monitoring_source\": {
    \"hosts\": \"${MONITORING_HOSTS}\",
    \"api_key\": \"${MONITORING_API_KEY}\",
    \"max_retries\": ${MONITORING_MAX_RETRIES:-5},
    \"retry_on_timeout\": ${MONITORING_RETRY:-true},
    \"request_timeout\": ${MONITORING_TIMEOUT:-60},
    \"verify_certs\": ${MONITORING_VERIFY_CERTS:-true}
  }"

# Conditionally add on_prem_costs to CONFIG_JSON if BILLING_API_KEY is not defined
if [ -z "${BILLING_API_KEY}" ]; then
    ON_PREM_COSTS_JSON=$(cat <<EOF
  ,
  "on_prem_costs": {
    "hot": ${ON_PREM_COSTS_HOT:-1.0},
    "warm": ${ON_PREM_COSTS_WARM:-0.5},
    "cold": ${ON_PREM_COSTS_COLD:-0.25},
    "frozen": ${ON_PREM_COSTS_FROZEN:-0.1}
  }
EOF
)
    CONFIG_JSON="${CONFIG_JSON}${ON_PREM_COSTS_JSON}"
fi

# Finalize the JSON
CONFIG_JSON="${CONFIG_JSON}
}"

# Use CONFIG_JSON in your script as needed
#echo $CONFIG_JSON

python main.py init --inline-config "$CONFIG_JSON"
if [ -n "$BILLING_API_KEY" ]; then
    echo "Consuming Billing"

    # Since BILLING_API_KEY is already set, you can directly use it
    #echo "Billing API Key: $BILLING_API_KEY"
    # Execute your Python script with the environment variable. Adjust the command as needed.
    python main.py get-billing-data --lookbehind=24 --inline-config "$CONFIG_JSON"
else
    echo "BILLING_API_KEY not found or it is empty."
fi

echo "Consume Monitoring"
python main.py consume-monitoring --lookbehind=24 --inline-config "$CONFIG_JSON"



exit 0