#!/bin/bash

# Define environment variables with default values when not provided.
LOOKBEHIND=${LOOKBEHIND:-12}
FORCE=${FORCE:-"--force"}


# Step 1: Run init command
echo "Running init command..."
if ! python main.py init; then
    echo "Init command failed. Exiting."
    exit 1
fi

# Step 2: Immediately run consume-monitoring and get-billing-data commands
echo "Running consume-monitoring command..."
if ! python main.py consume-monitoring --lookbehind=$LOOKBEHIND $FORCE; then
    echo "Consume-monitoring command failed. Exiting."
    exit 1
fi

echo "Running get-billing-data command..."
if ! python main.py get-billing-data --lookbehind=$LOOKBEHIND $FORCE; then
    echo "Get-billing-data command failed. Exiting."
    exit 1
fi

## SINGLE, RUNNING CONTAINER WITH CRON JOBS
# To run the cron jobs inside a single container, comment out the above commands and uncomment the below:

# Define a path for the initialisation flag file at the root level
#INIT_FLAG="/container_initialised.flag"

# Check if the container has been initialised before
#if [ ! -f "$INIT_FLAG" ]; then
    #echo "First time container startup. Running initial commands..."

    # Step 1: Run init command
    #python /main.py init

    # Step 2: Immediately run consume-monitoring and get-billing-data commands
    #python /main.py consume-monitoring --lookbehind=12 --force
    #python /main.py get-billing-data --lookbehind=12 --force

    # Mark initialisation as complete
    #touch "$INIT_FLAG"
#else
    #echo "Container restarted. Skipping initial commands."
#fi

# Step 3: Setup cron jobs for hourly execution (this part always executes)
# Print existing crontab jobs, ignore errors if no crontab yet
#crontab -l 2>/dev/null

# Prepare and add new cron jobs
#echo "0 * * * * python /main.py consume-monitoring --lookbehind=12 --force" >> mycron
#echo "0 * * * * python /main.py get-billing-data --lookbehind=12 --force" >> mycron

# Install a new cron file
#crontab mycron
#rm mycron

# Start cron in the foreground to keep the container running
#cron -f
###