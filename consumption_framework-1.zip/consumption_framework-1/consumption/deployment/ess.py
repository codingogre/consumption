import logging
from datetime import datetime
from typing import Optional

import pandas as pd
import requests

from ..utils import ESSResource, ESSURLs

logger = logging.getLogger(__name__)


class DeploymentFinder:
    def __init__(self, ess_api_key: str, organization_id: str, api_host: str):
        es_filters = [
            {
                "nested": {
                    "path": "resources.elasticsearch",
                    "query": {"exists": {"field": "resources.elasticsearch.id"}},
                }
            },
            {
                "nested": {
                    "path": "resources.elasticsearch",
                    "query": {
                        "match": {
                            "resources.elasticsearch.info.settings.metadata.organization_id": {
                                "query": organization_id
                            }
                        }
                    },
                }
            },
        ]

        res = requests.post(
            url=ESSURLs(api_host).ESS_SEARCH_DEPLOYMENTS_URL,
            headers={"Authorization": "ApiKey " + ess_api_key},
            json={
                "size": 1500,
                "query": {"bool": {"filter": es_filters}},
            },
        )
        res.raise_for_status()

        deployments = res.json()["deployments"]

        logger.debug(
            f"Found {len(deployments)} deployments for organization {organization_id}"
        )

        self.deployments = deployments
        self.elasticsearch_id_cache = {}
        self.deployment_id_cache = {}

    def get_deployment_id(self, elasticsearch_id: str) -> str:
        """
        Get the deployment id for the given elasticsearch_id.
        """
        if elasticsearch_id not in self.elasticsearch_id_cache:
            for deployment in self.deployments:
                for es in deployment["resources"]["elasticsearch"]:
                    if es["info"]["cluster_id"] == elasticsearch_id:
                        logger.debug(
                            f"Found deployment ID {deployment['id']} "
                            f"for elasticsearch_id {elasticsearch_id}"
                        )

                        # Populate both caches
                        self.elasticsearch_id_cache[elasticsearch_id] = deployment["id"]
                        self.deployment_id_cache[deployment["id"]] = elasticsearch_id

        return self.elasticsearch_id_cache.get(elasticsearch_id)


def get_elasticsearch_costs(
    organization_id: str,
    deployment_id: Optional[str],
    ess_api_key: str,
    from_ts: datetime,
    to_ts: datetime,
    api_host: str,
) -> pd.DataFrame:
    """
    Get cost of individual ES instances for a given deployment.
    Returns a dict of {instance_configuration: price}
    Since this can vary over time, we use the given time to fetch the costs.
    """

    if not deployment_id:
        logger.warning(
            "No deployment_id provided, skipping cost fetching - does the deployment still exist?"
        )
        # an empty dataframe will make the processing function exit gracefully
        return pd.DataFrame()

    logger.debug(
        f"Fetching costs for deployment {deployment_id} between {from_ts.isoformat()} and {to_ts.isoformat()}"
    )

    res = requests.get(
        url=ESSURLs(api_host).ESS_BILLING_URL % (organization_id, deployment_id),
        headers={"Authorization": "ApiKey " + ess_api_key},
        params={
            "from": from_ts.isoformat(timespec="microseconds"),
            "to": to_ts.isoformat(timespec="microseconds"),
        },
    )
    res.raise_for_status()

    resources = res.json().get("resources", [])

    prices = []
    for resource in resources:
        ess_resource = ESSResource(resource)

        if ess_resource.type != "elasticsearch" or ess_resource.tier == "system":
            continue

        # If we already have a price for this tier, log it
        if ess_resource.tier in [price["tier"] for price in prices]:
            logger.warning(
                f"Found multiple prices for tier {ess_resource.tier} for deployment {deployment_id} between {from_ts.isoformat()} and {to_ts.isoformat()}"
            )
            logger.warning(f"Full resources: {resources}")

        prices.append(
            {
                "tier": ess_resource.tier,
                "price_per_hour_per_gb": ess_resource.price_per_hour_per_gb,
            }
        )

    logger.debug(
        f"Found prices for deployment ID {deployment_id} between "
        f"{from_ts.strftime('%Y-%m-%d %H:%M:%S')} and "
        f"{to_ts.strftime('%Y-%m-%d %H:%M:%S')}: {prices}"
    )

    return pd.DataFrame(prices).set_index("tier") if prices else pd.DataFrame()
