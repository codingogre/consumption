import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, List, Tuple

from tqdm.contrib.logging import tqdm_logging_redirect

logger = logging.getLogger(__name__)


class ParallelRetrier:
    """
    ThreadPoolExecutor-based class that will continuously retry the given tasks until they succeed.
    """

    def __init__(
        self,
        workers: int = 10,
        max_retry: int = 3,
        on_success_callback: Callable = lambda x: None,
        on_failure_callback: Callable = lambda x: None,
        on_success_params: Dict = {},
        on_failure_params: Dict = {},
    ):
        self.workers = workers
        self.max_retry = max_retry
        self.on_success_callback = on_success_callback
        self.on_failure_callback = on_failure_callback
        self.on_success_params = on_success_params
        self.on_failure_params = on_failure_params

        # Dictionary to keep track of tasks
        # Each key/value pair is a task and a tuple of:
        # - the function to be executed
        # - the parameters to be passed to the function
        # - the number of retries
        # This allows us to keep track of the number of retries for each task,
        # and to retry the task if it fails (up to a maximum number of retries).
        self.tasks_map = {}

        # Counters for tasks statuses
        self.completed_tasks = 0
        self.error_count = 0

    def _submit_tasks(self, executor, tasks):
        self.tasks_map = {
            executor.submit(function, **params): (
                function,
                params,
                0,  # This is our retry counter
            )
            for function, params in tasks
        }

    def _failsafe(self):
        """
        Killswitch that cancels all remaining tasks if the failure rate gets too high.
        """
        if (
            self.error_count > 100
            and self.completed_tasks != 0
            and self.error_count / self.completed_tasks > 0.3
        ):
            logger.critical("More than 30% of tasks errored - aborting processing")
            [task.cancel() for task in self.tasks_map.keys()]
            sys.exit(1)

    def _process_tasks(self, executor):
        """
        Blocking function that polls the completed tasks of the executor,
        keeps tracks of processing stats and resubmits workload when needed.
        """
        with tqdm_logging_redirect(total=len(self.tasks_map), desc="Tasks") as pbar:
            while self.completed_tasks < len(self.tasks_map):
                # Do we have too many errors?
                self._failsafe()

                # Check the completed tasks
                for result in as_completed(self.tasks_map):
                    is_complete, is_success = self._handle_task_result(executor, result)

                    # Remove the task from the tracking map
                    # If need be, we re-submitted it in the _handle_task_result function
                    del self.tasks_map[result]

                    if is_complete:
                        pbar.update(1)
                        self.completed_tasks += 1

                    if not is_success:
                        self.error_count += 1

    def _handle_task_result(self, executor, result):
        """
        Handle the result of a task.
        Returns a two booleans:
        - whether the task completed
        - whether the task *successfully* completed
        """

        if result.exception():
            self.on_failure_callback(result.exception(), **self.on_failure_params)

            # Get task parameters
            function, params, past_retry_count = self.tasks_map[result]

            # Check if we should retry
            if past_retry_count >= self.max_retry:
                logger.error(
                    f"Task failed after {past_retry_count} retries - will stop retrying"
                )
                # Task completed, but not successfully
                return True, False
            else:
                # Submit the task once more for processing
                retry = executor.submit(function, **params)
                self.tasks_map[retry] = (
                    function,
                    params,
                    past_retry_count + 1,
                )

                logger.info(
                    f"Task failed {past_retry_count + 1} times - resubmitting for retry"
                )

                # Task retried
                return False, False
        else:
            self.on_success_callback(result.result(), **self.on_success_params)

            # Task completed, successfully
            return True, True

    def run(
        self,
        tasks: List[Tuple[Callable, Dict]],
    ):
        with ThreadPoolExecutor(self.workers) as executor:
            self._submit_tasks(executor, tasks)
            self._process_tasks(executor)
