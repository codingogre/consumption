import logging
import sys

import colorlog


class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class Logger(metaclass=Singleton):
    def __init__(self):
        logging_string = (
            "%(asctime)s [%(threadName)s] - %(levelname)s (%(funcName)s): %(message)s"
        )
        formatter = logging.Formatter(logging_string)
        if sys.stdout.isatty():
            formatter = colorlog.ColoredFormatter(
                "%(log_color)s" + logging_string,
            )

        handler = colorlog.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        self.handler = handler

        logger = colorlog.getLogger("consumption")
        logger.addHandler(handler)

        self.logger = logger

    def __getattr__(self, attr):
        return getattr(self.logger, attr)
